var URL = "https://fir-1c7de-default-rtdb.firebaseio.com/demoproject";
function checkIsNull(value) {
    return value === "" || value === undefined || value === null ? true : false;
}
let adminUser = "admin@gmail.com";
let adminPassword = "Admin@1234";

function loginUser() {
    let requestBody = {
        "mailId": $("#mailId").val(),
        "password": $("#pwdId").val()
    }
    if (checkIsNull($("#mailId").val()) || checkIsNull($("#pwdId").val())) {
        alert("Please fill Required Data");

    } else if (requestBody.mailId.trim() === adminUser) {
        if (requestBody.mailId.trim() === adminUser && requestBody.password === adminPassword) {
            localStorage.setItem("userName", "ADMIN");
            localStorage.setItem("userId", "1234567");
            window.location.href = "universityAttendnaceHome.html";

        } else {
            alert("Email and password are not matching");
        }
    } else {
        if (!$("#studentlId").prop('checked') && !$("#professorlId").prop('checked')) {
            alert("Please select one user type");
        }
        else if ($("#studentlId").prop('checked') && $("#professorlId").prop('checked')) {
            alert("please select one user type");

        } else {
            let regUrl = $("#studentlId").prop('checked') ? URL + '/studentRegData.json' : URL + '/professorRegData.json'
            $.ajax({
                type: 'get',
                contentType: "application/json",
                dataType: 'json',
                cache: false,
                url: regUrl,
                success: function (response) {
                    let loginUserList = [];
                    for (let i in response) {
                        let data = response[i];
                        data["userId"] = i;
                        loginUserList.push(data);
                    }
                    let isValid = false;
                    for (let i = 0; i < loginUserList.length; i++) {
                        if (loginUserList[i].mailId == $("#mailId").val() && loginUserList[i].password == $("#pwdId").val()) {
                            isValid = true;
                            localStorage.setItem("userId", loginUserList[i].userId);
                            localStorage.setItem("userData", JSON.stringify(loginUserList[i]));
                            $("#mailId").val('');
                            window.location.href = "universityAttendnaceHome.html";

                        }
                    }
                    if (!isValid) {
                        alert("User not found");
                    }

                }, error: function (error) {
                    alert("Something went wrong");
                }
            });
        }
    }

}

